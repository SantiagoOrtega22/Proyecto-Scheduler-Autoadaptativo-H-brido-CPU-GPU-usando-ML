import { useState, useMemo } from "react";
import { Check, Plus, Flame, X, ChevronRight, BarChart2, CalendarDays, Calendar, Leaf, Brain, Dumbbell, BookOpen, Focus, ChevronLeft } from "lucide-react";

type Categoria = "Todas" | "Cuerpo" | "Mente" | "Conocimiento" | "Enfoque";

interface Habito {
  id: number;
  nombre: string;
  descripcion: string;
  categoria: Exclude<Categoria, "Todas">;
  racha: number;
  completadoHoy: boolean;
  historial: boolean[]; // last 7 days, index 0 = oldest
  meta: number; // days per week goal
}

const CATEGORIAS: Categoria[] = ["Todas", "Cuerpo", "Mente", "Conocimiento", "Enfoque"];

const CATEGORIA_ICONS: Record<Categoria, React.ReactNode> = {
  Todas: <Leaf size={14} />,
  Cuerpo: <Dumbbell size={14} />,
  Mente: <Brain size={14} />,
  Conocimiento: <BookOpen size={14} />,
  Enfoque: <Focus size={14} />,
};

const CATEGORIA_COLORS: Record<Exclude<Categoria, "Todas">, string> = {
  Cuerpo: "#5C8B6A",
  Mente: "#8B5E3C",
  Conocimiento: "#6B7A8B",
  Enfoque: "#A0735A",
};

const DIAS_SEMANA = ["L", "M", "X", "J", "V", "S", "D"];

const habitosIniciales: Habito[] = [
  {
    id: 1,
    nombre: "Meditación matutina",
    descripcion: "10 minutos al despertar",
    categoria: "Mente",
    racha: 12,
    completadoHoy: true,
    historial: [true, true, false, true, true, true, true],
    meta: 7,
  },
  {
    id: 2,
    nombre: "Ejercicio",
    descripcion: "Al menos 30 min de movimiento",
    categoria: "Cuerpo",
    racha: 21,
    completadoHoy: true,
    historial: [true, true, true, true, false, true, true],
    meta: 5,
  },
  {
    id: 3,
    nombre: "Leer 30 minutos",
    descripcion: "Sin pantallas, libro físico",
    categoria: "Conocimiento",
    racha: 7,
    completadoHoy: false,
    historial: [true, false, true, true, true, false, false],
    meta: 7,
  },
  {
    id: 4,
    nombre: "Agua (8 vasos)",
    descripcion: "Hidratación consciente durante el día",
    categoria: "Cuerpo",
    racha: 5,
    completadoHoy: false,
    historial: [false, true, true, false, true, true, false],
    meta: 7,
  },
  {
    id: 5,
    nombre: "Diario personal",
    descripcion: "Reflexión de 5 minutos al anochecer",
    categoria: "Mente",
    racha: 3,
    completadoHoy: false,
    historial: [false, false, false, false, true, true, false],
    meta: 5,
  },
  {
    id: 6,
    nombre: "Sin redes antes del mediodía",
    descripcion: "Las mañanas son para ti",
    categoria: "Enfoque",
    racha: 9,
    completadoHoy: true,
    historial: [true, true, false, true, true, true, true],
    meta: 7,
  },
  {
    id: 7,
    nombre: "Aprender algo nuevo",
    descripcion: "Curso, podcast o artículo largo",
    categoria: "Conocimiento",
    racha: 4,
    completadoHoy: false,
    historial: [false, true, false, true, false, true, false],
    meta: 3,
  },
];

const HOY = new Date();
const FECHA_FORMATEADA = HOY.toLocaleDateString("es-ES", {
  weekday: "long",
  day: "numeric",
  month: "long",
  year: "numeric",
});

function capitalizar(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function Modal({ onClose, onAdd }: { onClose: () => void; onAdd: (h: Omit<Habito, "id" | "racha" | "historial">) => void }) {
  const [nombre, setNombre] = useState("");
  const [descripcion, setDescripcion] = useState("");
  const [categoria, setCategoria] = useState<Exclude<Categoria, "Todas">>("Mente");
  const [meta, setMeta] = useState(7);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!nombre.trim()) return;
    onAdd({ nombre: nombre.trim(), descripcion: descripcion.trim(), categoria, meta, completadoHoy: false });
    onClose();
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-foreground/30 backdrop-blur-sm">
      <div
        className="bg-card border border-border rounded-xl shadow-2xl w-full max-w-md mx-4 p-8"
        style={{ fontFamily: "'Lato', sans-serif" }}
      >
        <div className="flex items-start justify-between mb-6">
          <div>
            <h2
              className="text-2xl font-medium text-foreground"
              style={{ fontFamily: "'Playfair Display', serif" }}
            >
              Nuevo hábito
            </h2>
            <p className="text-sm text-muted-foreground mt-0.5">Pequeños pasos, grandes cambios</p>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors p-1"
          >
            <X size={18} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-5">
          <div>
            <label className="block text-xs font-medium text-muted-foreground uppercase tracking-widest mb-2">
              Nombre
            </label>
            <input
              type="text"
              value={nombre}
              onChange={(e) => setNombre(e.target.value)}
              placeholder="ej. Caminar 20 minutos"
              className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-accent/30 text-sm"
              autoFocus
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground uppercase tracking-widest mb-2">
              Descripción (opcional)
            </label>
            <input
              type="text"
              value={descripcion}
              onChange={(e) => setDescripcion(e.target.value)}
              placeholder="¿Cómo y cuándo lo harás?"
              className="w-full bg-secondary border border-border rounded-lg px-4 py-2.5 text-foreground placeholder:text-muted-foreground/60 focus:outline-none focus:ring-2 focus:ring-accent/30 text-sm"
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground uppercase tracking-widest mb-2">
              Categoría
            </label>
            <div className="grid grid-cols-2 gap-2">
              {(["Cuerpo", "Mente", "Conocimiento", "Enfoque"] as const).map((cat) => (
                <button
                  key={cat}
                  type="button"
                  onClick={() => setCategoria(cat)}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg border text-sm transition-all"
                  style={{
                    background: categoria === cat ? CATEGORIA_COLORS[cat] : "transparent",
                    borderColor: categoria === cat ? CATEGORIA_COLORS[cat] : "var(--border)",
                    color: categoria === cat ? "#FBF7EE" : "var(--foreground)",
                  }}
                >
                  {CATEGORIA_ICONS[cat]}
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-muted-foreground uppercase tracking-widest mb-2">
              Meta semanal — {meta} {meta === 1 ? "día" : "días"}
            </label>
            <input
              type="range"
              min={1}
              max={7}
              value={meta}
              onChange={(e) => setMeta(Number(e.target.value))}
              className="w-full accent-accent"
            />
            <div className="flex justify-between text-xs text-muted-foreground mt-1">
              <span>1 día</span>
              <span>7 días</span>
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-lg border border-border text-foreground/70 hover:text-foreground text-sm transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 rounded-lg text-sm font-medium transition-colors"
              style={{ background: "var(--accent)", color: "var(--accent-foreground)" }}
            >
              Crear hábito
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function HabitCard({ habito, onToggle }: { habito: Habito; onToggle: () => void }) {
  const color = CATEGORIA_COLORS[habito.categoria];
  const completadosHoy = habito.historial.filter(Boolean).length;
  const porcentaje = Math.round((completadosHoy / 7) * 100);

  return (
    <div
      className="bg-card border border-border rounded-xl p-5 transition-all duration-200 hover:shadow-md group"
      style={{ borderLeft: `3px solid ${color}` }}
    >
      <div className="flex items-start gap-4">
        <button
          onClick={onToggle}
          className="mt-0.5 w-6 h-6 rounded-full border-2 flex-shrink-0 flex items-center justify-center transition-all duration-200"
          style={{
            borderColor: habito.completadoHoy ? color : "var(--border)",
            background: habito.completadoHoy ? color : "transparent",
          }}
        >
          {habito.completadoHoy && <Check size={12} strokeWidth={3} color="#FBF7EE" />}
        </button>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p
                className="font-medium text-foreground leading-snug"
                style={{
                  textDecoration: habito.completadoHoy ? "line-through" : "none",
                  opacity: habito.completadoHoy ? 0.55 : 1,
                  fontFamily: "'Lato', sans-serif",
                }}
              >
                {habito.nombre}
              </p>
              {habito.descripcion && (
                <p className="text-xs text-muted-foreground mt-0.5" style={{ fontFamily: "'Lato', sans-serif" }}>
                  {habito.descripcion}
                </p>
              )}
            </div>
            <div className="flex items-center gap-1 flex-shrink-0">
              <Flame size={13} style={{ color }} />
              <span className="text-sm font-medium" style={{ color, fontFamily: "'DM Mono', monospace" }}>
                {habito.racha}
              </span>
            </div>
          </div>

          <div className="mt-3 flex items-center gap-3">
            <div className="flex gap-1">
              {DIAS_SEMANA.map((dia, i) => (
                <div key={dia} className="flex flex-col items-center gap-1">
                  <div
                    className="w-5 h-5 rounded-sm"
                    style={{
                      background: habito.historial[i] ? color : "var(--secondary)",
                      opacity: habito.historial[i] ? 0.85 : 1,
                    }}
                    title={dia}
                  />
                </div>
              ))}
            </div>
            <span
              className="text-xs text-muted-foreground"
              style={{ fontFamily: "'DM Mono', monospace" }}
            >
              {porcentaje}% esta semana
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

// Generate a realistic fake month of completions for each habit
function generarHistorialMensual(habitos: Habito[], year: number, month: number): Record<number, Record<number, number>> {
  // Returns { habitId: { day: pct 0-1 } }
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date();
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;
  const lastDay = isCurrentMonth ? today.getDate() : daysInMonth;

  const result: Record<number, Record<number, number>> = {};
  for (const h of habitos) {
    result[h.id] = {};
    // Use a seeded-ish pattern based on habit id + day
    for (let d = 1; d <= lastDay; d++) {
      const seed = (h.id * 13 + d * 7) % 17;
      const prob = h.racha > 14 ? 0.85 : h.racha > 7 ? 0.72 : 0.55;
      result[h.id][d] = seed / 17 < prob ? 1 : 0;
    }
    // Last 7 days mirror the stored historial
    const offset = lastDay - 7;
    for (let i = 0; i < 7; i++) {
      const day = offset + i + 1;
      if (day >= 1 && day <= lastDay) {
        result[h.id][day] = h.historial[i] ? 1 : 0;
      }
    }
    // today
    if (isCurrentMonth) {
      result[h.id][today.getDate()] = h.completadoHoy ? 1 : 0;
    }
  }
  return result;
}

const MESES_ES = [
  "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
  "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre",
];

function CalendarView({ habitos }: { habitos: Habito[] }) {
  const today = new Date();
  const [viewDate, setViewDate] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selectedDay, setSelectedDay] = useState<number | null>(today.getDate());

  const year = viewDate.getFullYear();
  const month = viewDate.getMonth();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDow = (new Date(year, month, 1).getDay() + 6) % 7; // Monday-first
  const isCurrentMonth = today.getFullYear() === year && today.getMonth() === month;
  const lastVisibleDay = isCurrentMonth ? today.getDate() : daysInMonth;

  const historialMensual = useMemo(
    () => generarHistorialMensual(habitos, year, month),
    [habitos, year, month]
  );

  // Intensity per day: 0–1 (fraction of habits completed)
  const intensidadDia = useMemo(() => {
    const map: Record<number, number> = {};
    for (let d = 1; d <= lastVisibleDay; d++) {
      const completados = habitos.filter((h) => historialMensual[h.id]?.[d]).length;
      map[d] = habitos.length > 0 ? completados / habitos.length : 0;
    }
    return map;
  }, [habitos, historialMensual, lastVisibleDay]);

  function prevMonth() {
    setViewDate(new Date(year, month - 1, 1));
    setSelectedDay(null);
  }
  function nextMonth() {
    const next = new Date(year, month + 1, 1);
    if (next <= new Date(today.getFullYear(), today.getMonth(), 1)) {
      setViewDate(next);
      setSelectedDay(null);
    }
  }
  const canGoNext = new Date(year, month + 1, 1) <= new Date(today.getFullYear(), today.getMonth(), 1);

  const selectedHabitos = selectedDay
    ? habitos.map((h) => ({ ...h, _ok: !!historialMensual[h.id]?.[selectedDay] }))
    : [];

  const cells: (number | null)[] = [
    ...Array(firstDow).fill(null),
    ...Array.from({ length: daysInMonth }, (_, i) => i + 1),
  ];
  // Pad to complete last row
  while (cells.length % 7 !== 0) cells.push(null);

  return (
    <div className="space-y-4">
      {/* Month navigator */}
      <div className="flex items-center justify-between px-1 mb-2">
        <button
          onClick={prevMonth}
          className="p-2 rounded-lg hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground"
        >
          <ChevronLeft size={16} />
        </button>
        <h3
          className="text-lg text-foreground"
          style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500 }}
        >
          {MESES_ES[month]} <span className="text-muted-foreground text-base">{year}</span>
        </h3>
        <button
          onClick={nextMonth}
          disabled={!canGoNext}
          className="p-2 rounded-lg hover:bg-secondary transition-colors text-muted-foreground hover:text-foreground disabled:opacity-30 disabled:cursor-not-allowed"
        >
          <ChevronRight size={16} />
        </button>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        {/* Day headers */}
        <div className="grid grid-cols-7 border-b border-border">
          {["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"].map((d) => (
            <div
              key={d}
              className="py-2 text-center text-xs uppercase tracking-widest text-muted-foreground"
              style={{ fontFamily: "'DM Mono', monospace" }}
            >
              {d}
            </div>
          ))}
        </div>

        {/* Calendar grid */}
        <div className="grid grid-cols-7">
          {cells.map((day, i) => {
            const isFuture = day !== null && (!isCurrentMonth || day > today.getDate());
            const isPast = day !== null && !isFuture;
            const isToday = isCurrentMonth && day === today.getDate();
            const isSelected = day === selectedDay;
            const intensity = day ? (intensidadDia[day] ?? 0) : 0;

            // Color fill based on completion intensity
            let bgColor = "transparent";
            if (isPast && day) {
              const alpha = 0.15 + intensity * 0.7;
              bgColor = `rgba(139, 94, 60, ${alpha})`;
            }

            return (
              <button
                key={i}
                disabled={!day || isFuture}
                onClick={() => day && !isFuture && setSelectedDay(day === selectedDay ? null : day)}
                className="relative aspect-square flex flex-col items-center justify-center transition-all duration-150 group"
                style={{
                  borderRight: (i + 1) % 7 !== 0 ? "1px solid var(--border)" : "none",
                  borderBottom: i < cells.length - 7 ? "1px solid var(--border)" : "none",
                  background: isSelected
                    ? "var(--accent)"
                    : isPast && day
                    ? bgColor
                    : "transparent",
                  cursor: day && !isFuture ? "pointer" : "default",
                }}
              >
                {day && (
                  <>
                    <span
                      className="text-sm leading-none"
                      style={{
                        fontFamily: "'DM Mono', monospace",
                        color: isSelected
                          ? "#FBF7EE"
                          : isToday
                          ? "var(--accent)"
                          : isFuture
                          ? "var(--muted-foreground)"
                          : "var(--foreground)",
                        fontWeight: isToday ? 700 : 400,
                        opacity: isFuture ? 0.35 : 1,
                      }}
                    >
                      {day}
                    </span>
                    {isPast && intensity > 0 && !isSelected && (
                      <div className="flex gap-0.5 mt-1">
                        {habitos.slice(0, 4).map((h) => (
                          <div
                            key={h.id}
                            className="w-1 h-1 rounded-full"
                            style={{
                              background: historialMensual[h.id]?.[day]
                                ? CATEGORIA_COLORS[h.categoria]
                                : "var(--border)",
                            }}
                          />
                        ))}
                      </div>
                    )}
                  </>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center gap-3 px-1">
        <span className="text-xs text-muted-foreground">Menos</span>
        {[0.15, 0.35, 0.55, 0.75, 0.9].map((a) => (
          <div
            key={a}
            className="w-4 h-4 rounded-sm"
            style={{ background: `rgba(139, 94, 60, ${a})` }}
          />
        ))}
        <span className="text-xs text-muted-foreground">Más</span>
      </div>

      {/* Selected day detail */}
      {selectedDay && (
        <div className="bg-card border border-border rounded-xl p-5 mt-2">
          <p
            className="text-base font-medium text-foreground mb-4"
            style={{ fontFamily: "'Playfair Display', serif" }}
          >
            {selectedDay} de {MESES_ES[month]}
            {isCurrentMonth && selectedDay === today.getDate() && (
              <span className="ml-2 text-xs text-accent font-normal" style={{ fontFamily: "'DM Mono', monospace" }}>
                hoy
              </span>
            )}
          </p>
          <div className="space-y-2">
            {selectedHabitos.map((h) => (
              <div key={h.id} className="flex items-center gap-3">
                <div
                  className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{
                    background: h._ok ? CATEGORIA_COLORS[h.categoria] : "var(--secondary)",
                    border: `1.5px solid ${h._ok ? CATEGORIA_COLORS[h.categoria] : "var(--border)"}`,
                  }}
                >
                  {h._ok && <Check size={10} strokeWidth={3} color="#FBF7EE" />}
                </div>
                <span
                  className="text-sm"
                  style={{
                    color: h._ok ? "var(--foreground)" : "var(--muted-foreground)",
                    textDecoration: !h._ok ? "none" : "none",
                  }}
                >
                  {h.nombre}
                </span>
                <span
                  className="ml-auto text-xs"
                  style={{
                    color: CATEGORIA_COLORS[h.categoria],
                    fontFamily: "'DM Mono', monospace",
                  }}
                >
                  {h.categoria}
                </span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-border flex items-center justify-between">
            <span className="text-xs text-muted-foreground">Completados ese día</span>
            <span
              className="text-sm font-medium text-foreground"
              style={{ fontFamily: "'DM Mono', monospace" }}
            >
              {selectedHabitos.filter((h) => h._ok).length}/{habitos.length}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  const [habitos, setHabitos] = useState<Habito[]>(habitosIniciales);
  const [categoriaActiva, setCategoriaActiva] = useState<Categoria>("Todas");
  const [modalAbierto, setModalAbierto] = useState(false);
  const [vistaActiva, setVistaActiva] = useState<"hoy" | "stats" | "calendario">("hoy");

  const habitosFiltrados =
    categoriaActiva === "Todas"
      ? habitos
      : habitos.filter((h) => h.categoria === categoriaActiva);

  const completadosHoy = habitos.filter((h) => h.completadoHoy).length;
  const porcentajeHoy = Math.round((completadosHoy / habitos.length) * 100);
  const rachaMasLarga = Math.max(...habitos.map((h) => h.racha));

  function toggleHabito(id: number) {
    setHabitos((prev) =>
      prev.map((h) =>
        h.id === id
          ? {
              ...h,
              completadoHoy: !h.completadoHoy,
              racha: !h.completadoHoy ? h.racha + 1 : Math.max(0, h.racha - 1),
            }
          : h
      )
    );
  }

  function agregarHabito(nuevo: Omit<Habito, "id" | "racha" | "historial">) {
    setHabitos((prev) => [
      ...prev,
      {
        ...nuevo,
        id: Date.now(),
        racha: 0,
        historial: [false, false, false, false, false, false, false],
      },
    ]);
  }

  return (
    <div
      className="min-h-screen bg-background"
      style={{ fontFamily: "'Lato', sans-serif" }}
    >
      {modalAbierto && (
        <Modal onClose={() => setModalAbierto(false)} onAdd={agregarHabito} />
      )}

      <div className="max-w-5xl mx-auto px-4 md:px-8 py-8 md:py-12">
        {/* Header */}
        <header className="mb-10">
          <p
            className="text-xs uppercase tracking-widest text-muted-foreground mb-2"
            style={{ fontFamily: "'DM Mono', monospace" }}
          >
            {capitalizar(FECHA_FORMATEADA)}
          </p>
          <h1
            className="text-4xl md:text-5xl text-foreground leading-tight"
            style={{ fontFamily: "'Playfair Display', serif", fontWeight: 500 }}
          >
            Diseño de <em style={{ fontStyle: "italic" }}>hábitos</em>
          </h1>
          <p className="text-muted-foreground mt-2 text-sm">
            {completadosHoy} de {habitos.length} hábitos completados hoy
          </p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-[240px_1fr] gap-8">
          {/* Sidebar */}
          <aside className="space-y-6">
            {/* Progress Ring */}
            <div className="bg-card border border-border rounded-xl p-6 text-center">
              <div className="relative inline-flex items-center justify-center">
                <svg width="100" height="100" viewBox="0 0 100 100">
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    fill="none"
                    stroke="var(--secondary)"
                    strokeWidth="8"
                  />
                  <circle
                    cx="50"
                    cy="50"
                    r="42"
                    fill="none"
                    stroke="var(--accent)"
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={`${2 * Math.PI * 42}`}
                    strokeDashoffset={`${2 * Math.PI * 42 * (1 - porcentajeHoy / 100)}`}
                    transform="rotate(-90 50 50)"
                    style={{ transition: "stroke-dashoffset 0.6s ease" }}
                  />
                </svg>
                <div className="absolute text-center">
                  <span
                    className="text-2xl font-medium text-foreground block"
                    style={{ fontFamily: "'DM Mono', monospace" }}
                  >
                    {porcentajeHoy}%
                  </span>
                </div>
              </div>
              <p className="text-xs text-muted-foreground mt-2 uppercase tracking-widest">hoy</p>
            </div>

            {/* Stats */}
            <div className="bg-card border border-border rounded-xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-widest text-muted-foreground">Racha mayor</span>
                <div className="flex items-center gap-1">
                  <Flame size={14} className="text-accent" />
                  <span
                    className="text-sm font-medium text-foreground"
                    style={{ fontFamily: "'DM Mono', monospace" }}
                  >
                    {rachaMasLarga} días
                  </span>
                </div>
              </div>
              <div className="border-t border-border" />
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-widest text-muted-foreground">Hábitos activos</span>
                <span
                  className="text-sm font-medium text-foreground"
                  style={{ fontFamily: "'DM Mono', monospace" }}
                >
                  {habitos.length}
                </span>
              </div>
              <div className="border-t border-border" />
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-widest text-muted-foreground">Completados</span>
                <span
                  className="text-sm font-medium text-foreground"
                  style={{ fontFamily: "'DM Mono', monospace" }}
                >
                  {completadosHoy}/{habitos.length}
                </span>
              </div>
            </div>

            {/* Categorías */}
            <div className="bg-card border border-border rounded-xl p-5">
              <p className="text-xs uppercase tracking-widest text-muted-foreground mb-3">Categorías</p>
              <div className="space-y-1">
                {CATEGORIAS.map((cat) => {
                  const count =
                    cat === "Todas"
                      ? habitos.length
                      : habitos.filter((h) => h.categoria === cat).length;
                  return (
                    <button
                      key={cat}
                      onClick={() => setCategoriaActiva(cat)}
                      className="w-full flex items-center justify-between px-3 py-2 rounded-lg text-sm transition-all duration-150"
                      style={{
                        background:
                          categoriaActiva === cat
                            ? cat === "Todas"
                              ? "var(--primary)"
                              : CATEGORIA_COLORS[cat as Exclude<Categoria, "Todas">]
                            : "transparent",
                        color:
                          categoriaActiva === cat
                            ? "#FBF7EE"
                            : "var(--foreground)",
                      }}
                    >
                      <span className="flex items-center gap-2">
                        {CATEGORIA_ICONS[cat]}
                        {cat}
                      </span>
                      <span
                        className="text-xs opacity-70"
                        style={{ fontFamily: "'DM Mono', monospace" }}
                      >
                        {count}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Add button */}
            <button
              onClick={() => setModalAbierto(true)}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-dashed border-border hover:border-accent text-muted-foreground hover:text-accent text-sm transition-all duration-150"
            >
              <Plus size={16} />
              Nuevo hábito
            </button>
          </aside>

          {/* Main */}
          <main>
            {/* Tab nav */}
            <div className="flex items-center justify-between mb-6">
              <div className="flex gap-1 bg-secondary rounded-lg p-1">
                <button
                  onClick={() => setVistaActiva("hoy")}
                  className="flex items-center gap-2 px-4 py-2 rounded-md text-sm transition-all duration-150"
                  style={{
                    background: vistaActiva === "hoy" ? "var(--card)" : "transparent",
                    color: vistaActiva === "hoy" ? "var(--foreground)" : "var(--muted-foreground)",
                    boxShadow: vistaActiva === "hoy" ? "0 1px 3px rgba(0,0,0,0.08)" : "none",
                  }}
                >
                  <CalendarDays size={14} />
                  Hoy
                </button>
                <button
                  onClick={() => setVistaActiva("stats")}
                  className="flex items-center gap-2 px-4 py-2 rounded-md text-sm transition-all duration-150"
                  style={{
                    background: vistaActiva === "stats" ? "var(--card)" : "transparent",
                    color: vistaActiva === "stats" ? "var(--foreground)" : "var(--muted-foreground)",
                    boxShadow: vistaActiva === "stats" ? "0 1px 3px rgba(0,0,0,0.08)" : "none",
                  }}
                >
                  <BarChart2 size={14} />
                  Semana
                </button>
                <button
                  onClick={() => setVistaActiva("calendario")}
                  className="flex items-center gap-2 px-4 py-2 rounded-md text-sm transition-all duration-150"
                  style={{
                    background: vistaActiva === "calendario" ? "var(--card)" : "transparent",
                    color: vistaActiva === "calendario" ? "var(--foreground)" : "var(--muted-foreground)",
                    boxShadow: vistaActiva === "calendario" ? "0 1px 3px rgba(0,0,0,0.08)" : "none",
                  }}
                >
                  <Calendar size={14} />
                  Mes
                </button>
              </div>

              <button
                onClick={() => setModalAbierto(true)}
                className="flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors"
                style={{ background: "var(--accent)", color: "var(--accent-foreground)" }}
              >
                <Plus size={14} />
                Añadir
              </button>
            </div>

            {vistaActiva === "hoy" ? (
              <>
                {habitosFiltrados.length === 0 ? (
                  <div className="bg-card border border-border rounded-xl p-12 text-center">
                    <p className="text-muted-foreground text-sm">
                      No hay hábitos en esta categoría todavía.
                    </p>
                    <button
                      onClick={() => setModalAbierto(true)}
                      className="mt-4 text-accent text-sm flex items-center gap-1 mx-auto hover:underline"
                    >
                      <Plus size={14} /> Crear uno ahora
                    </button>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {/* Pendientes */}
                    {habitosFiltrados.some((h) => !h.completadoHoy) && (
                      <div>
                        <p className="text-xs uppercase tracking-widest text-muted-foreground mb-3 px-1">
                          Pendientes —{" "}
                          {habitosFiltrados.filter((h) => !h.completadoHoy).length}
                        </p>
                        <div className="space-y-2">
                          {habitosFiltrados
                            .filter((h) => !h.completadoHoy)
                            .map((h) => (
                              <HabitCard key={h.id} habito={h} onToggle={() => toggleHabito(h.id)} />
                            ))}
                        </div>
                      </div>
                    )}

                    {/* Completados */}
                    {habitosFiltrados.some((h) => h.completadoHoy) && (
                      <div className="mt-6">
                        <p className="text-xs uppercase tracking-widest text-muted-foreground mb-3 px-1">
                          Completados —{" "}
                          {habitosFiltrados.filter((h) => h.completadoHoy).length}
                        </p>
                        <div className="space-y-2">
                          {habitosFiltrados
                            .filter((h) => h.completadoHoy)
                            .map((h) => (
                              <HabitCard key={h.id} habito={h} onToggle={() => toggleHabito(h.id)} />
                            ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </>
            ) : vistaActiva === "stats" ? (
              /* Vista Semana */
              <div className="space-y-3">
                <p className="text-xs uppercase tracking-widest text-muted-foreground mb-3 px-1">
                  Últimos 7 días
                </p>
                <div className="bg-card border border-border rounded-xl overflow-hidden">
                  {/* Header row */}
                  <div
                    className="grid items-center border-b border-border px-5 py-3"
                    style={{ gridTemplateColumns: "1fr repeat(7, 32px)" }}
                  >
                    <span className="text-xs uppercase tracking-widest text-muted-foreground">Hábito</span>
                    {DIAS_SEMANA.map((d) => (
                      <span
                        key={d}
                        className="text-xs text-muted-foreground text-center"
                        style={{ fontFamily: "'DM Mono', monospace" }}
                      >
                        {d}
                      </span>
                    ))}
                  </div>

                  {habitos.map((h, i) => {
                    const color = CATEGORIA_COLORS[h.categoria];
                    const total = h.historial.filter(Boolean).length;
                    return (
                      <div
                        key={h.id}
                        className="grid items-center px-5 py-3.5 hover:bg-secondary/40 transition-colors"
                        style={{
                          gridTemplateColumns: "1fr repeat(7, 32px)",
                          borderBottom: i < habitos.length - 1 ? "1px solid var(--border)" : "none",
                        }}
                      >
                        <div className="pr-4 min-w-0">
                          <p className="text-sm text-foreground truncate">{h.nombre}</p>
                          <p className="text-xs text-muted-foreground mt-0.5 flex items-center gap-1">
                            <span
                              className="w-1.5 h-1.5 rounded-full inline-block"
                              style={{ background: color }}
                            />
                            {h.categoria}
                          </p>
                        </div>
                        {h.historial.map((ok, j) => (
                          <div key={j} className="flex justify-center">
                            <div
                              className="w-6 h-6 rounded-sm flex items-center justify-center"
                              style={{
                                background: ok ? color : "var(--secondary)",
                              }}
                            >
                              {ok && <Check size={10} strokeWidth={3} color="#FBF7EE" />}
                            </div>
                          </div>
                        ))}
                      </div>
                    );
                  })}
                </div>

                {/* Resumen categorías */}
                <div className="grid grid-cols-2 gap-3 mt-4">
                  {(["Cuerpo", "Mente", "Conocimiento", "Enfoque"] as const).map((cat) => {
                    const catHabitos = habitos.filter((h) => h.categoria === cat);
                    if (catHabitos.length === 0) return null;
                    const totalCompletados = catHabitos.reduce(
                      (acc, h) => acc + h.historial.filter(Boolean).length,
                      0
                    );
                    const totalPosibles = catHabitos.length * 7;
                    const pct = Math.round((totalCompletados / totalPosibles) * 100);
                    const color = CATEGORIA_COLORS[cat];
                    return (
                      <div key={cat} className="bg-card border border-border rounded-xl p-4">
                        <div className="flex items-center gap-2 mb-2">
                          <span style={{ color }}>{CATEGORIA_ICONS[cat]}</span>
                          <span className="text-sm text-foreground">{cat}</span>
                        </div>
                        <div className="h-1.5 bg-secondary rounded-full overflow-hidden">
                          <div
                            className="h-full rounded-full transition-all duration-500"
                            style={{ width: `${pct}%`, background: color }}
                          />
                        </div>
                        <p
                          className="text-xs text-muted-foreground mt-2"
                          style={{ fontFamily: "'DM Mono', monospace" }}
                        >
                          {pct}% esta semana
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : vistaActiva === "calendario" ? (
              <CalendarView habitos={habitos} />
            ) : null}
          </main>
        </div>
      </div>
    </div>
  );
}
